package com.example.demo.utils;
public record ChangePassword(String password, String repeatPassword) {
}