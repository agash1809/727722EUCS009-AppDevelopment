package com.example.demo.utils;
import lombok.Data;
@Data
public class RefreshTokenRequest {
    private String refreshToken;
}
