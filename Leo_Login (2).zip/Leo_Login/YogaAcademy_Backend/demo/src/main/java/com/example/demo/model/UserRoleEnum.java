package com.example.demo.model;
public enum UserRoleEnum {
    USER,ADMIN
}